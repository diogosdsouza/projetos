var vel = 60.5
console.log(`a velocidade do seu veiculo é de ${vel}km/h`)
console.log('dirija sempre com o cinto de segurança')