# PHPMyAdmin

# O PHPMyAdmin é uma aplicação web com o objetivo facilitar/automatizar a criação e manipulação dos bancos de dados.

# Podemos acessá-lo pelo WampServer, clicando na aplicação phpMyAdmin que aparece no Menu e inserindo o login:
#login: root
#senha:       (vazia)


#####  O Banco de dados não está no MySQL, ele está no servidor e pode ser acessado por qualquer ferramenta de Banco de dados. ######
#####  Importante aprender os comandos SQL por escrito para poder usá-los junto com outras linguagens depois. ######


# Guanabara ensina comandos dentro do PHPMyAdmin, tudo muito intuitivo. Dá para fazer tudo por lá sem comandos escritos.


# No console: show create table _______ ; --> isso mostra o comando que foi utilizado para criar a tabela _______
# No console: show create database _______ ; --> isso mostra o comando que foi utilizado para criar a database _______
# (ÚTIL PARA APRENDER COMANDOS)



#Testando se o comando veio para o Workbench:
select * from amigos;


