#### AULA 6 ####


#Fizemos BACKUP do BASEDADOS (teste_backup)


#monitorar processos do banco de dados:
show processlist 


#CRUD é a ação que uma aplicação faz dentro de um banco de dados

#create/insert
#read/select
#update
#delete
