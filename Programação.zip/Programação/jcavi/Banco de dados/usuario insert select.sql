#### Este usuário só pode fazer SELECT e INSERT

select * from cadastro

insert into cadastro(nome_cadastro,sobrenome,cpf,cep)
values ("Maria","Souza",'44447','2222')


#Não tem permissão
delete from cadastro where nome='João'


#DML:
#Insert Update Delete

#DDL:
#Create Drop Alter


#DQL:
#Select