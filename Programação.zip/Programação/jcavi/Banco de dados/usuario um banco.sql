#Tem permissão pra fazer TUDO em apenas UM banco

delete from cadastro
where id_cad=2

insert into cadastro(nome_cadastro,sobrenome,cpf,cep)
values ("Lua","Sol","4637383","2347476")