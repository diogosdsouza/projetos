#Este usuário pode fazer apenas SELECT

select * from produtos

insert into cadastro (nome_cadastro,sobrenome,cpf,cep) 
values ("Pedro","Golias","12345678987","22345678")