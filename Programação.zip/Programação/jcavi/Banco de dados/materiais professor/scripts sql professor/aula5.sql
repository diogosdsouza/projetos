### ViEWS de Banco de dados ######
# views são constituidas de selects são chamadas de virtual tables.alter
# AS views acessam as informações das tabelas fisicas tabelas reais chamadas de
# based tables

# Vamos construir uma view fazendo o join da consulta da tabelas cadastro e produtos

create or replace view cadastro_produtos as
select  nome_cadastro,nome_produtos,Quantidade,Valor,CPF
from cadastro
join produtos on
cadastro.id_cad = produtos.id_prod
order by nome_cadastro



select * from cadastro_produtos
where quantidade >20


create or replace view view2 as
select  nome_cadastro,Quantidade
from cadastro
join produtos on
cadastro.id_cad = produtos.id_prod
order by quantidade


select * from view2


## Ver processo no banco de dados

show processlist


####### Indices de banco de dados ####

# Indices de banco de dados servem para otimizar consultas em cima de campos de tabelas
# que sofrem muitas consultas ou levam muito para completar a consulta
# Os indices atuam como uma prioridade que o SGDB aplica para campos que possuem
# indices

create table cliente(
id_cliente integer not null auto_increment,
cod_cliente varchar(10),
Nome varchar(50),
sobrenome varchar(50),
CPF varchar(11),
d_cadastro date,
primary key(id_cliente),
index ind_cod_cliente(cod_cliente)
);


## Adicionar um indice a uma tabela ja existente

alter table cliente add index ind_nome_cliente(nome);

alter table cadastro add index ind_nome_cadastro(nome_cadastro);


show indexes from cadastro


select * from cadastros_externos

####### Exportar Dados do Banco de dados e Importar em formato CSV ########

## Exportar nossa tabela

select * from produtos into outfile 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/lista_produtos.csv'
fields terminated by ';';


## Barras de diretorios

# \ windows
# / linux 


## Propriedade de uma variavel

show variables like "secure_file_priv"


## Criar a tabela que vai receber os dados importados


create table importvendas(
CodigoPedido int(10),
EmailCliente varchar(100),
CodigoCliente integer(10),
Qtd integer(10),
CodigoProduto integer(10),
CategoriaProduto varchar(50),
primary key(CodigoPedido)
);


# importar os do arquivo

load data infile 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/clientes.csv'
into table importvendas fields terminated by ';' lines terminated by '\n'
ignore 1 rows;


select * from importvendas








