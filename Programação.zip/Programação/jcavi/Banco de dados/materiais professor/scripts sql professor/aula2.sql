### Comando DDL Alter faz uma alteração estrutural de uma
#tabela ou objeto do banco de dados

# Adicionar o campo CEP na tabela cadastro

select * from cadastro

alter table cadastro add column CEP varchar(10) after cpf


update cadastro set cep='1111110' 
where id_cad = 3 or id_cad = 6


insert into cadastro(id_cad,nome,sobrenome,cpf) values (2,"Pedro","Feliciano",'22222')


############# Trabalhando com Selects ###########

## Order by ordena por uma coluna se for texto e ordem alfabetica 
# se for numero por ordinal 1 2 3

select nome,sobrenome from cadastro
order by nome

select nome,sobrenome from cadastro
order by nome desc     # decrescente

## Vamos usar o where (onde) utiliza uma condição

select nome,sobrenome from cadastro
where nome = 'João'

select nome,sobrenome from cadastro
where nome !="João" # diferente de João


select id_cad,nome,sobrenome from cadastro
where id_cad > 3


## Busca coringa

select nome,sobrenome from cadastro
where nome like 'Jo%'

select nome,sobrenome from cadastro
where nome like '%ria'

select nome,sobrenome from cadastro
where sobrenome like 'S%za'


#### Consultas lógicas or(ou) and(E) not(negacao)

select nome,sobrenome from cadastro
where nome='Roberto' or sobrenome='Silva'

select nome,sobrenome from cadastro
where nome = "Roberto" and sobrenome="Ferreira"

select nome,sobrenome from cadastro
where not nome='Roberto'

### Clausulas in e not in

select id_cad,nome,sobrenome from cadastro
where id_cad in (1,2)

select id_cad,nome,sobrenome from cadastro
where id_cad  not in (1,2)

select id_cad,nome,sobrenome from cadastro
where id_cad between 1 and 4

# Exemplo de busca entre intervalos de data

#select id_cad,nome,sobrenome from cadastro
#where datacadastro between '2023-01-01' and '2023-31-01'

## Distinct tras apenas os valores distintos nao repetidos

select distinct sobrenome from cadastro

## Vamos criar a nossa segunda tabela e criar os relacionamentos
# Ou chave estrangeira ou no modelo fisico constraint

create table produtos(
id_prod integer not null auto_increment,
nome varchar(50) not null,
valor float not null,
quantidade int(11) not null,
id_cad integer not null,
primary key(id_prod)
);

## Vamos criar a constraint que é a interligacao fisica das tabelas

alter table produtos add constraint fk_cadastro_produtos
foreign key(id_cad)
references cadastro(id_cad)

select * from cadastro

select * from produtos


### Subconsulta ou Subselects
# E um select dentro de outro select 
# Essa subconsultas também estao fazendo um join(mais amador)

select nome,sobrenome from cadastro
where id_cad in (select id_cad from produtos where id_cad);

select nome,sobrenome from cadastro
where id_cad not in (select id_cad from produtos where id_cad);


# È um select com juncao de 2 tabelas

select nome,(select nome from cadastro where id_cad = produtos.id_cad)
from produtos ;

# Criando alias nos campos para sair mais organizados

select nome as produtos,(select nome from cadastro where id_cad = produtos.id_cad) as Compradores
from produtos ;

################# Clausula Join ############

# Select sem join

select nome_cadastro,nome_produtos,sobrenome,valor,quantidade
from produtos,cadastro
where cadastro.id_cad = produtos.id_cad
order by Quantidade

## Para corrigir a ambiguidade vamos renomear os nome dos campos das 
# tabelas

alter table cadastro change nome nome_cadastro varchar(50);

alter table produtos change nome nome_produtos varchar(50);

## Select com join

select * from produtos
join cadastro

select nome_cadastro,nome_produtos,quantidade from produtos
join cadastro on
produtos.id_cad = cadastro.id_cad
order by nome_cadastro

# Exemplo 3 tabela no join
#join estoque on
#produtos.id_prod = estoque.id_prod

## Quando precisamos trazer valores relacionados no select
# De 2 ou mais tabelas e recomendado utilziar o join pela facilidade
# E clareza relacional


## Joins para analise LEFT JOIN o RIGHT JOIN
# compara valores da esquerda com a direta
# E compara valores da direita para esquerda

## LEFT JOIN

select * from cadastro
left join produtos on
produtos.id_cad = cadastro.id_cad

# Right Join

select * from produtos
right join cadastro on
produtos.id_cad = cadastro.id_cad




