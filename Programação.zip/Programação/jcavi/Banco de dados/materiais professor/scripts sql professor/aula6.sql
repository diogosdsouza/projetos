# Monitorar processos do banco de dados

show processlist

## Matar consulta do banco de dados
# PID é o id do processo da consulta do banco de dados

kill 29

########################### REVISAO COMANDOS SQL ################



select * from cadastro

insert into cadastro(nome_cadastro,sobrenome,cpf,cep) values ("Maria","Souza",'4447','2222')

delete from cadastro where nome = 'João'

delete from cadastro 
where nome = 'João' and  sobrenome = "Cavichiolli"


drop table cadastro

update cadastro set nome= "João"
where id_cad = 2

## Comandos de manipulação de registros sao o tipo DML

# DML
# Insert update delete

## Comandos DDL definicao ou estrutura de dados

# DROP CREATE ALTER

# DQL - Date Query - select 

# CRUD é a ação que uma aplicação faz dentro de um banco de dados
#DML/DQL

#Create/insert
#Read/select
#Update
#Delete

truncate cadastro



