##		########## Funções em Banco de dados #####
# Funções em banco de dados servem para executar determinadas ações ou tarefas
# pre compiladas e armazenadas no banco de dados sempre que precisamos executa-la
# Funções são usadas para ações ou consultas repetitivas ou diarias

# Criar um function que iremos passar como parametro o id do cadastro
# Ela ira nos retornar o nome desse ID

delimiter $$

create function retorna_nome(id integer) # parametro da função
returns varchar(50) deterministic
begin ## Abre bloco de codigo

declare nome varchar(50); # declara uma variavel 
select nome_cadastro into nome from cadastro
where id_cad = id;
return nome;
end $$

delimiter $$

## Testar a function

select retorna_nome(12)

## Function para fazer um join

select nome_produtos,retorna_nome(8),Quantidade from produtos


############### Stored Procedures ############


# stored procedures são programações compiladas dentro do banco de dados
# Onde executam determinadas ações e atividades manualmente ou em 2 plano(agendadas)


delimiter $$

create procedure stp_select()
begin
select * from produtos;
end $$
delimiter $$


## Chamar uma procedure

call stp_select()

## Criar uma procedure de carga de dados 
# Onde ele ira copiar os registros da tabelas produtos para a produtos2


select * from produtos2

# truncate apaga todos os registro de uma tabela

truncate produtos2


DELIMITER $$
CREATE PROCEDURE st_input_tabela_produtos2()
BEGIN
DECLARE done INT DEFAULT FALSE;
DECLARE INSERE_ID_PROD int default 0;
DECLARE INSERE_NOME varchar(30) default 0;
DECLARE INSERE_Valor float(10,2) default 0;
DECLARE INSERE_Quantidade int default 0;
DECLARE INSERE_ID_CAD int;
DECLARE cursor1 CURSOR FOR SELECT id_prod,Nome_produtos,Valor,Quantidade,id_cad from produtos;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; # e a condicao de parada do laco e cursor
OPEN cursor1;
read_loop: LOOP # while
IF done THEN
LEAVE read_loop;
END IF;

FETCH cursor1 INTO
INSERE_ID_PROD,INSERE_NOME,INSERE_VALOR,INSERE_QUANTIDADE,INSERE_ID_CAD;
insert into produtos2
Values(INSERE_ID_PROD,INSERE_NOME,INSERE_VALOR,INSERE_QUANTIDADE,INSERE_ID_CAD);
end loop;
CLOSE cursor1;
END $$
delimiter $$

# Chamando a procedure para a carga da tabela

call st_input_tabela_produtos2()

select * from produtos2

truncate produtos2

## Criar um evento agendado para rodar nossa procedure

## Ativar o scheduler

set global event_scheduler = on;

## Criar uma tarefa agendada para rodar a procedure a cada 1 minuto

delimiter $$

create event chama_procedure on schedule every 1 minute
on completion not preserve disable
do 
call st_input_tabela_produtos2()

# Exibe as tarefas agendadas

show events

## Ativar a tarefa agendada

alter event chama_procedure disable

drop event chama_procedure

truncate produtos2

select * from produtos2

############# Triggers Gatilhos ###

# A triggers ou chamada de ações de regra de negocio são condicionadas as executar a partir
# de uma ação pre determinada. After insert after update after delete
# Ela sao mais rapida que as procedures e sao a prova de falha(sempre ocorrera apos um evento)

# Vamos criar uma tabela para simular os eventos da trigger(tabela de vendas)

create table ItensVenda(
id_venda int,
id_prod int,
Qt_Vendida int
);

delimiter $

create trigger itensvenda_Insert after insert
on itensvenda
for each row
begin
update produtos set quantidade= quantidade - new.qt_vendida
where id_prod = new.id_prod;
end$
create trigger itensvenda_delete after delete
on itensvenda
for each row
begin
update produtos set quantidade = quantidade + old.qt_vendida
where id_prod = old.id_prod;
end$
delimiter $

## Testar as triggers

insert into itensvenda (id_venda,id_prod,qt_vendida) values(1,6,15)

delete from itensvenda
where id_venda =1

#exibir as triggers

show triggers

# Apagar a trigger
drop trigger itensvenda_Insert

# Vamos criar uma trigger condicional(tem uma condicao de valores de campo de tabela)

## Implemetar um campo de status de venda

alter table itensvenda add column status_venda varchar(50);

## Criar a trigger condicional

delimiter $

create trigger itensvenda_insert after insert
on itensvenda
for each row
begin
if new.status_venda = 'vendeu' then
update produtos set quantidade = quantidade - new.qt_vendida
where id_prod = new.id_prod;
end if;
if new.status_venda ='devolveu' then
update produtos set quantidade = quantidade + new.qt_vendida
where id_prod = new.id_prod;
end if;
end$

delimiter $

## Testar as triggers com condicionais

insert into itensvenda (id_venda,id_prod,qt_vendida,status_venda) values
(1,7,10,'vendeu')

insert into itensvenda (id_venda,id_prod,qt_vendida,status_venda) values
(2,7,5,'devolveu')


select * from itensvenda





