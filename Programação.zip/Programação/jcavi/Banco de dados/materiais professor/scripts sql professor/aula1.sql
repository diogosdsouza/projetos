-- comentario são linhas de codigo não lidas pelo sql
#  pode ser # ou -- duplo traço

# Vamos criar a base de dados com comando DDL
create database basedados;

## Vamos criar a primeira tabela chamada cadastro
# utilizando o comando do tipo DDL create

create table cadastro(
id_cad integer not null auto_increment,
Nome varchar(50) not null,
Sobrenome varchar(50) not null,
CPF varchar(11) not null,
primary key(id_cad)
);

###  UTilizando o comando DML Insert para criar um registo
# na tabela cadastro

insert into cadastro (nome,sobrenome,cpf)
values('João', 'Cavichiolli', '44444');

## Vamos executar um comando DQL Select para 
# consultar e pesquisar os registros de uma tabela

select * from cadastro;

select nome,sobrenome from cadastro

## Sempre que vamos apagar ou fazer um update em algum
# registro de uma tabelas precisamos ser especificos
# UTilizando clausula Where e passando campos de 
# valores unicos

delete from cadastro where id_cad = 2

select * from cadastro

update cadastro set sobrenome = "Cunha"
where sobrenome = "Cavichiolli"










