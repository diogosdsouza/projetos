### Select e Funções ####

## Criar uma tabela uma tabela utilizando select

create table produtos2(
select * from produtos where quantidade >=10)

select * from produtos2

## Copiar todos os registro da tabela produto para produtos2

insert into produtos2 (
select id_prod,Nome_produtos,valor,quantidade,id_cad from produtos)


update produtos2 set Nome_produtos = 'Abacaxi'
where nome_produtos in ( select nome_produtos from produtos)

##  Funções de Agregação ###
# São responsaveis por agrupar valores onde o resultado
# será um unico

select Quantidade,Nome_cadastro as Cliente_Vendido
from produtos,cadastro
where cadastro.id_cad = produtos.id_cad
order by Quantidade;

## Group by ele agrupa registro repetidos

# vamos repetitr um registro 

insert into produtos(nome_produtos,valor,quantidade,id_cad)
values ('Laranja',3.50,15,1)

select * from produtos


select nome_produtos,nome_cadastro,quantidade as QT_Vendido
from cadastro,produtos
where cadastro.id_cad = produtos.id_cad
group by nome_produtos,nome_cadastro,quantidade
order by nome_produtos

## Função count conta registros de uma tabela

select count(nome_produtos) from produtos;

select nome_cadastro,nome_produtos,count(nome_produtos) as Contagem_Produtos,sum(quantidade) as Quantidade_Produtos
from produtos,cadastro
where cadastro.id_cad = produtos.id_cad
group by nome_cadastro,nome_produtos
having count(nome_produtos) < 3

## MAX e o MIN maximo valor e o minimo valor

select min(Quantidade) as QT_PROD_MIN,max(Quantidade) as QT_PROD_MAX from produtos

## Sum faz o soma total em um unico soma agregadora

select sum(Quantidade)as QT_Total,format(sum(valor),3) as Valor_Total 
from produtos

## Média de um valor com a função avg

select format(avg(valor),3) as Média from produtos


## Funções de String ##
# Manipular valores de texto ou varchar

# Função substring e usada para caputar uma parte dos dados

#Funcao length e utilizada para contar caracter

 select nome_produtos from produtos
 where substr(Nome_produtos,1,2) = 'ma'
 and length(nome_produtos) > 5
 
 
 ## Concat e concat_ws
 
 # concat ele concatena o resultados das colunas
 
 select concat(nome_cadastro,'Gosta de:  ',nome_produtos) as Gosto_Frutas
 from cadastro,produtos
 where cadastro.id_cad = produtos.id_cad
 order by Nome_cadastro

## Concat_ws utiliza um separador para cada campo de um registro


select concat_ws(',',Nome_produtos,Quantidade,valor)
from produtos
where nome_produtos like 'M%'

# lcase e ucase

## Lower case letras em minusculo
## upper case letras em maiusculo

select lcase(nome_produtos),ucase(nome_produtos) from produtos

## Funções de Calculos e Operadores aritméticos

## Arrendondamento round

select round(3645.6333,2) from dual

## Raiz Quadrada

select sqrt(443) as Raiz_Quadrada

select pi()

## Calculos matemáticos: Adição, Subtracao,Divisão,Multiplicacao

# Multiplicacao

select(quantidade*(valor+valor)) as multiplicacao from produtos
where id_prod = 4


# Adição

select(quantidade+valor) as multiplicacao from produtos
where id_prod = 4


# substracao

select(quantidade-valor) as multiplicacao from produtos
where id_prod = 4


# Divisao

select(quantidade/valor) as multiplicacao from produtos
where id_prod = 4

### Funções de data ########

## Funcao para trazer a data atual

select curdate() as DATA_HOJE

## Trazer data e hora atual

select now()
select sysdate()

# Trazer apenas a hora

select curtime()

# Campo tipo date '2023-01-25' 
# campo tipo time '20:34:00'

## Analises com valores de horas

select datediff('2023-01-30','2020-06-01') as Diferença_Dias

## Adicionar um valor a uma data

select date_add(now(),interval 60 day)

#Extrair o dia da semana de uma data

select dayname('2018-09-28');

## Extrair o ano de uma data
select extract(year from '2022-09-01')


#Retornar ultimo dia do mes de uma tabela ou valor

select last_day('2022-02-01')

## Alterar padrao de formato de data e hora

select date_format('2015-11-23',get_format(date,'EUR'))

## Transformar datas em formato para formato de data

select str_to_date('04.10.2020',get_format(date,'USA'));

####  Uso de IF e CASE no SQL #####

# IF

# Testar a quantidade de frutas em estoque e trazer um resultado
# do select como alto e baixo.

select nome_produtos,Quantidade,
if(quantidade<=20,"Baixo","Alto")as Estoque
from produtos;

## Validação de Valores

select valor,
if(valor <> 10.00,"Diferente","Igual") as valores
from produtos;


## Vamos utilizar o mesmo cenário de estoque mas 
# vamos utilizar a função CASE pois teremos mais de 1 condição
# verdadeira

select 

case

when quantidade <= 4 then "Baixo Estoque"

when quantidade <= 15 then "Estoque Bom"

when quantidade <= 30 then "Estoque Médio"

else 'Estoque Alto'
end as estadoestoque,
count(*)estadoestoque
from produtos
group by estadoestoque
order by estadoestoque

## Utilizar o if com join 
# Analisar clientes com compras de quantidade acima de 10

select nome_cadastro,nome_produtos,quantidade,
if(quantidade>=10,"Alto","Baixo") as QT_Compras
from produtos join cadastro on
cadastro.id_cad = produtos.id_cad
order by QT_Compras

## Case classificando cliente com vendas boas e ruins


select
case
when quantidade <= 10 then "Clientes com Poucas Vendas"
else "Cliente com Vendas Boas"
end as Compras_clientes,
count(*)Compras_clientes
from produtos join cadastro on
cadastro.id_cad = produtos.id_cad
group by Compras_clientes
order by Compras_Clientes

 





