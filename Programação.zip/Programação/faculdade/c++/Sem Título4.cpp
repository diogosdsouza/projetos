#include <stdio.h>
#include <stdlib.h>

int main(){
	float nota,cont,media[20];
	for(cont=0;cont<=20;cont++){
	media[cont];
	printf("\nEscreva uma nota: ");
	scanf("%f",&nota);
	if(nota>=6)
		printf("%f",media[cont]);
}
printf("As notas na media são: %f",media);
}