#include<stdio.h>
#include<conio.h>

int main(){
	var x: registro
	inicio
		matricula : int
		salario : float
	fim
	x.matricula = 10
	printf(x.matricula)
}
