'''
Praticando faculdade
'''