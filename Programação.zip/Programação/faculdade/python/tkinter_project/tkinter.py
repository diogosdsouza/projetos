import tkinter as tk
from tkinter import messagebox as mb    #para messagebox
janela = tk.Tk()
janela.title(" Aplicação GUI")  #titulo da janela
#janela.resizable(False, False)  #para deixar a janela não dimensionável


#T = tk.Text(janela, height=2,width=30)  #para escrever um texto
#T.pack()                                #para escrever um texto
#T.insert(tk.END, "texto")               #para escrever um texto


#mensagem_para_usuario = "mensagem \npara o usuário"     #escrever mensagem para o usuário
#msg = tk.Message(janela, text = mensagem_para_usuario)  #escrever mensagem para o usuário
#msg.pack()                                              #escrever mensagem para o usuário

#Tipos de MESSAGEBOX
#def resposta():
#   mb.showerror("Resposta", "Desculpe, nenhuma resposta disponível!")   #balão de resposta
#def verificacao():
#   if mb.askyesno('Verificar', 'Realmente quer sair?'):                 #balão de verificação
#      mb.showwarning('Yes', 'Ainda não foi implementado')               #balão de warnig
#   else:
#      mb.showinfo('No', 'A opção de Sair foi cancelada')                #balão de info
#tk.Button(text='Sair', command=verificacao).pack(fill=tk.X)
#tk.Button(text='Resposta', command=resposta).pack(fill=tk.X)
janela.mainloop()